# External Content

Files in this directory are from other open-source repos by Xilinx Inc.

DO NOT CREATE NEW FILES HERE EXCEPT FOR MAINTAIN SCRIPTS.
